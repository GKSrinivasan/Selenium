﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using Laserbeam.QA.Automation.HR.Common.Resources;
using Laserbeam.QA.Automation.HR.Common.Common;
using System;
using Excel = Microsoft.Office.Interop.Excel;
using Laserbeam.QA.Automation.HR.Common.Constants;

namespace Laserbeam.QA.Automation.HR.TestCase.TestCase
{
    [TestClass]
    public class RewardsTestCase : BaseClass
    {
        #region Fields        
        static string serverPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
        static string filePath = serverPath.Split(new[] { CommonResource.Bin }, StringSplitOptions.None)[0];

        public static string FilePath
        {
            get
            {
                return filePath;
            }

            set
            {
                filePath = value;
            }
        }
        #endregion

        #region TestCase
        [TestMethod]
        public void Mer_0001()
        {
            string testID = "Mer_0001";
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(FilePath+ RewardsResource.TestDataPath + testID+CommonResource.ExcelExtension);
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
            Excel.Range xlRange = xlWorksheet.UsedRange;
            int rowCount = xlRange.Rows.Count;
            string inputID = "";
            for (int i = 2; i <= rowCount; i++)
            {
                try
                {
                    inputID = xlRange.Cells[i, 1].Text;
                    //Step 1: Launch the web browser
                    base.LaunchCompassLogin(CommonResource.ChromeBrowser, LoginResource.BaseURL + CommonResource.TenantName);
                    //Step 2: Login to Compass
                    var actualDashboardURL = base.Pages.LoginPage.Login(xlRange.Cells[i, 2].Text, xlRange.Cells[i, 3].Text);
                    Assert.AreEqual(actualDashboardURL, LoginResource.BaseURL + CommonResource.TenantName + DashboardResource.DashbaordURL);
                    //Step 3: Click on Administration in the menu
                    IWebElement ruleElement = base.Pages.DashboardPage.ClickAdministrationLink();
                    //Step 4: Select Rules under settings in the menu
                    var actualRuleURL = base.Pages.DashboardPage.ClickRulesTile();
                    Assert.AreEqual(actualRuleURL, LoginResource.BaseURL + CommonResource.TenantName + RulesResource.RulesURL);
                    //Step 5: Select @CompensationComponentsON
                    SetCompensationComponents(CompensationComponents.SelectMerit, CompensationComponents.DeselectPerformanceRating, CompensationComponents.DeselectLumpSum, CompensationComponents.DeselectPromotion, CompensationComponents.DeselectAdjustment, CompensationComponents.DeselectWorkflow, CompensationComponents.DeselectMultiCurrency);
                    //Step 6: Click on Save
                    var actualMessage = base.Pages.RulePage.ClickSaveButton();
                    Assert.AreEqual(actualMessage, RulesResource.SavedMessage);
                    //Step 7: Click on Rewards in the menu
                    var rewardsTile = base.Pages.DashboardPage.ClickRewardsLink();
                    //Step 8: Click on Recommend Increase 
                    var actualRewardsURL = base.Pages.DashboardPage.ClickRewardsTile();
                    Assert.AreEqual(actualRewardsURL, LoginResource.BaseURL + CommonResource.TenantName + RewardsResource.RewardsURL);
                    //Step 9: Provide Merit Pct in the textbox and tab out
                    var lockedGridContent = base.Pages.RewardsPage.GetLockedGridContent();
                    int index = 0; int setIndex = 0;
                    foreach (var item in lockedGridContent)
                    {
                        //Select Employee
                        if (item.Text == xlRange.Cells[i, 4].Text)
                            setIndex = index;
                        index++;
                    }
                    base.Pages.RewardsPage.InputMeritPct(xlRange.Cells[i, 5].Text, setIndex);
                    var actualMeritAmount = base.Pages.RewardsPage.GetMeritAmt(setIndex);
                    Assert.AreEqual(actualMeritAmount, xlRange.Cells[i, 6].Text);
                    var actualNewSalary = base.Pages.RewardsPage.GetNewSalaryLocal(setIndex);
                    Assert.AreEqual(actualNewSalary, xlRange.Cells[i, 7].Text);
                    //Step 10: Click on Save
                    var actualRewardsMessage = base.Pages.RewardsPage.ClickSaveButton();
                    Assert.AreEqual(actualRewardsMessage, RewardsResource.SavedMessage);
                    //Step 11: Click on Logout icon
                    base.Pages.DashboardPage.ClickLogOut();
                    base.BaseCleanUp(testID, inputID,CommonResource.Pass);
                }
                catch (Exception e)
                {                   
                    //Click on Logout icon
                    base.BaseCleanUp(testID, inputID,CommonResource.Fail,e.Message);
                }
            }
            xlWorkbook.Close();
            xlApp.Quit();
        }
        #endregion

        #region Configuration
        private void SetCompensationComponents(CompensationComponents merit, CompensationComponents performanceRating, CompensationComponents lumpSum, CompensationComponents promotion, CompensationComponents adjustment, CompensationComponents workflow, CompensationComponents multiCurrency)
        {
            var isMeritEnable = base.Pages.RulePage.IsMeritChecked();
            var isPerformanceRatingEnable = base.Pages.RulePage.IsPerformanceRatingChecked();
            var isLumpSumEnable = base.Pages.RulePage.IsLumpSumChecked();
            var isPromotionEnable = base.Pages.RulePage.IsPromotionChecked();
            var isAdjustmentEnable = base.Pages.RulePage.IsAdjustmentChecked();
            var isWorkflowEnable = base.Pages.RulePage.IsWorkFlowChecked();
            var isMultiCurrencyEnable = base.Pages.RulePage.IsMultiCurrencyChecked();

            if (merit == CompensationComponents.SelectMerit && isMeritEnable == null)
                base.Pages.RulePage.ClickMeritTile();
            else if (merit == CompensationComponents.DeselectMerit && isMeritEnable != null)
                base.Pages.RulePage.ClickMeritTile();
            if (performanceRating == CompensationComponents.SelectPerformanceRating && isPerformanceRatingEnable == null)
                base.Pages.RulePage.ClickPerformanceRatingTile();
            else if (performanceRating == CompensationComponents.DeselectPerformanceRating && isPerformanceRatingEnable != null)
                base.Pages.RulePage.ClickPerformanceRatingTile();
            if (lumpSum == CompensationComponents.SelectLumpSum && isLumpSumEnable == null)
                base.Pages.RulePage.ClickLumpSumTile();
            else if (lumpSum == CompensationComponents.DeselectLumpSum && isLumpSumEnable != null)
                base.Pages.RulePage.ClickLumpSumTile();
            if (promotion == CompensationComponents.SelectPromotion && isPromotionEnable == null)
                base.Pages.RulePage.ClickPromotionTile();
            else if (promotion == CompensationComponents.DeselectPromotion && isPromotionEnable != null)
                base.Pages.RulePage.ClickPromotionTile();
            if (adjustment == CompensationComponents.SelectAdjustment && isAdjustmentEnable == null)
                base.Pages.RulePage.ClickAdjustmentTile();
            else if (adjustment == CompensationComponents.DeselectAdjustment && isAdjustmentEnable != null)
                base.Pages.RulePage.ClickAdjustmentTile();
            if (workflow == CompensationComponents.SelectWorkflow && isWorkflowEnable == null)
                base.Pages.RulePage.ClickWorkflowTile();
            else if (workflow == CompensationComponents.DeselectWorkflow && isWorkflowEnable != null)
                base.Pages.RulePage.ClickWorkflowTile();
            if (multiCurrency == CompensationComponents.SelectMultiCurrency && isMultiCurrencyEnable == null)
                base.Pages.RulePage.ClickMultiCurrencyTile();
            else if (multiCurrency == CompensationComponents.DeselectMultiCurrency && isMultiCurrencyEnable != null)
                base.Pages.RulePage.ClickMultiCurrencyTile();
        }
        #endregion
    }
}


//base.Pages.RewardsPage.ClickManagerTree();
//var actualManagerName = base.Pages.RewardsPage.ChangeManager("CHARLES");