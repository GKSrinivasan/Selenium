﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Excel = Microsoft.Office.Interop.Excel;
using Laserbeam.QA.Automation.HR.Common.Resources;
using Laserbeam.QA.Automation.HR.Common.Common;

namespace Laserbeam.QA.Automation.HR.TestCase.TestCase
{
    [TestClass]
    public class LoginTestCase : BaseClass
    {
        #region Fields
        //Create COM Objects. Create a COM object for everything that is referenced
        static Excel.Application xlApp = new Excel.Application();
        static string serverPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
        static string filePath = serverPath.Split(new[] { "bin" }, StringSplitOptions.None)[0] + "TestData\\Login\\LoginData.xlsx";
        static Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(filePath);
        static Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
        static Excel.Range xlRange = xlWorksheet.UsedRange;
        static int rowCount = xlRange.Rows.Count;
        #endregion

        #region CleanUp
        [TestCleanup]
        public void CleanUp()
        {
            //close and release
            xlWorkbook.Close();
            //quit and release
            xlApp.Quit();
        }
        #endregion

        #region LoginTestCases
        [TestMethod]
        public void LoginWithValidUserNameandPassword()
        {
            string testCaseName = "";
            string input="";
            for (int i = 2; i <= rowCount; i++)
            {
                base.LaunchCompassLogin("Chrome", LoginResource.BaseURL+"Automation");
                try
                {
                    input = Convert.ToString(i - 1);
                    var actualResult = base.Pages.LoginPage.Login(xlRange.Cells[i, 2].Text, xlRange.Cells[i, 3].Text);
                    if (xlRange.Cells[i, 4].Text == "Valid")
                    {
                        testCaseName = "LoginWithVaildUser";
                        Assert.AreEqual(actualResult, xlRange.Cells[i, 5].Text);
                        base.BaseCleanUp("", "LoginWithVaildUser", CommonResource.Pass);
                    }
                    else if (xlRange.Cells[i, 4].Text == "Oops")
                    {
                        testCaseName = "LoginWithInValidPassword";
                        actualResult = base.Pages.LoginPage.GetMessage();
                        Assert.AreEqual(actualResult, xlRange.Cells[i, 5].Text);
                        base.BaseCleanUp("", "LoginWithInValidPassword", CommonResource.Pass);
                    }                    
                }
                catch(Exception e)
                {
                    base.BaseCleanUp("", "", CommonResource.Fail,e.Message);
                }
            }
        }
        #endregion
    }
}
