﻿using Laserbeam.QA.Automation.HR.Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Excel = Microsoft.Office.Interop.Excel;
using System.Web;
using System;

namespace Laserbeam.QA.Automation.HR.TestCase.TestCases.LoginTestCases
{
    [TestClass]
    public class Login: BaseClass
    {
        #region Fields
        //Create COM Objects. Create a COM object for everything that is referenced
        static Excel.Application xlApp = new Excel.Application();
        static string serverPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
        static string filePath = serverPath.Split(new[] { "bin" },StringSplitOptions.None)[0]+ "TestData\\Login\\LoginData.xlsx";
        static Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(filePath);
        static Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
        static Excel.Range xlRange = xlWorksheet.UsedRange;
        static int rowCount = xlRange.Rows.Count;
        #endregion

        [TestCleanup]
        public void CleanUp()
        {
            //close and release
            xlWorkbook.Close();
            //quit and release
            xlApp.Quit();
        }

        [TestMethod]
        public void LoginWithValidUserNameandPassword()
        {
            for (int i = 2; i <= rowCount; i++)
            {
                bool status = false;
                base.BaseInitialize();
                var actualResult = base.Pages.LoginPage.Login(xlRange.Cells[i, 1].Text, xlRange.Cells[i, 2].Text);
                if (xlRange.Cells[i, 3].Text == "Valid")
                {
                    status = (actualResult == xlRange.Cells[i, 4].Text);                    
                }
                else if (xlRange.Cells[i, 3].Text == "Oops")
                {
                    actualResult = base.Pages.LoginPage.GetMessage();
                    status = (actualResult == xlRange.Cells[i, 4].Text);
                }                
                xlRange.Cells[i, 5].Value2 = status;
                //xlWorkbook.Save();
                base.BaseCleanUp();
            }
            //string fileName = @"D:\TFS.111\Compass\SeleniumAutomation\Laserbeam.QA.Automation.HR.TestCase\TestData\Login\LoginData.xlsx";
            //HttpPostedFileBase fileContent = xlWorkbook.Sheets[1];
            //fileContent.SaveAs(fileName + DateTime.Now.ToString());
        }

        //public void Save()
        //{
        //    InputStream inp = new FileInputStream("workbook.xls");

        //    Workbook wb = WorkbookFactory.create(inp);
        //    Sheet sheet = wb.getSheetAt(0);
        //    Row row = sheet.getRow(2);
        //    Cell cell = row.getCell(3);
        //    if (cell == null)
        //        cell = row.createCell(3);
        //    cell.setCellType(Cell.CELL_TYPE_STRING);
        //    cell.setCellValue("a test");

        //    // Write the output to a file
        //    FileOutputStream fileOut = new FileOutputStream("workbook.xls");
        //    wb.write(fileOut);
        //    fileOut.close();
        //}
    }
}
