﻿using Laserbeam.QA.Automation.HR.Common.Elements;
using Laserbeam.QA.Automation.HR.Common.Operations;
using OpenQA.Selenium;
using System.Collections.ObjectModel;

namespace Laserbeam.QA.Automation.HR.Common.Pages
{
    public class RewardsPage
    {
        #region Fields
        private readonly IWebDriver browser;
        #endregion

        #region Constructor
        public RewardsPage(IWebDriver m_browser)
        {
            browser = m_browser;
        }
        #endregion

        #region Property
        public RewardElements Elements
        {
            get
            {
                return new RewardElements(browser);
            }
        }

        public RewardOperations Operations
        {
            get
            {
                return new RewardOperations(Elements);
            }
        }
        #endregion

        #region RewardsAction
        public ReadOnlyCollection<IWebElement> GetLockedGridContent()
        {
            return Operations.GetLockedGridContent();
        }

        public void ClickManagerTree()
        {
            Operations.ClickManagerTree();
        }

        public string ChangeManager(string managerName)
        {
            return Operations.ChangeManager(managerName);
        }

        public void InputMeritPct(string pct, int index)
        {
            Operations.InputMeritPct(pct, index);
        }

        public string GetMeritAmt(int index)
        {
            return Operations.GetMeritAmt(index);
        }

        public string GetNewSalaryLocal(int index)
        {
            return Operations.GetNewSalaryLocal(index);
        }

        public string ClickSaveButton()
        {
            return Operations.ClickSaveButton();
        }

        public string GetBudgetAmt()
        {
            return Operations.GetBudgetAmt();
        }

        public string GetBudgetPct()
        {
            return Operations.GetBudgetPct();
        }

        public string GetBalanceAmt()
        {
            return Operations.GetBalanceAmt();
        }

        public string GetBalancePct()
        {
            return Operations.GetBalancePct();
        }

        public void ClickPromotion(int index)
        {
            Operations.ClickPromotion(index);
        }

        public void InputPromotionTitlt(string title)
        {
            Operations.InputPromotionTitlt(title);
        }

        public void InputPromotionComment(string comment)
        {
            Operations.InputPromotionComment(comment);
        }

        public void ClickAddPromotionCommentButton()
        {
            Operations.ClickAddPromotionCommentButton();
        }

        public void SelectPerformanceRating(int index, string rating)
        {
            Operations.SelectPerformanceRating(index, rating);
        }

        public string GetNewCompaRatioMin(int index)
        {
            return Operations.GetNewCompaRatioMin(index);
        }

        public string GetNewCompaRatioMax(int index)
        {
            return Operations.GetNewCompaRatioMax(index);
        }

        public void ClickSpentSummaryLink()
        {
            Operations.ClickSpentSummaryLink();
        }

        public string SummaryMeritAmt()
        {
            return Operations.SummaryMeritAmt();
        }

        public string SummaryPromotionAmt()
        {
            return Operations.SummaryPromotionAmt();
        }

        public string SummaryLumpSumAmt()
        {
            return Operations.SummaryLumpSumAmt();
        }

        public string SummaryAdjustmentAmt()
        {
            return Operations.SummaryAdjustmentAmt();
        }

        public string SummaryRemainingAmt()
        {
            return Operations.SummaryRemainingAmt();
        }

        public string SummarySpentAmt()
        {
            return Operations.SummarySpentAmt();
        }

        public void ClickSpentSummaryClose()
        {
            Operations.ClickSpentSummaryClose();
        }

        public void ClickRewardsFilterButton()
        {
            Operations.ClickRewardsFilterButton();
        }

        public void SelectFilterColumn(string columnValue)
        {
            Operations.SelectFilterColumn(columnValue);
        }

        public void SelectFilterOperation(string operationValue)
        {
            Operations.SelectFilterOperation(operationValue);
        }

        public void SetSearchText(string searchText)
        {
            Operations.SetSearchText(searchText);
        }

        public void ClickAddButton()
        {
            Operations.ClickAddButton();
        }

        public void ClickFilterApplyButton()
        {
            Operations.ClickFilterApplyButton();
        }

        public void ClickFilterCloseButton()
        {
            Operations.ClickFilterCloseButton();
        }

        public void OpenCommentPopUp(int index)
        {
            Operations.OpenComentPopup(index);
        }

        public void ClcikCommentPopAddCommentButton()
        {
            Operations.ClcikCommentPopAddCommentButton();
        }

        public void ClcikCommentPopCancelButton()
        {
            Operations.ClcikCommentPopAddCommentButton();
        }

        public void EnterCommentPopComment(string comment)
        {
            Operations.EnterCommentPopComment(comment);
        }

        public void ClickSubmitButton()
        {
            Operations.ClickSubmitButton();
        }

        public void ClickApproveButton()
        {
            Operations.ClickApproveButton();
        }

        public void ClickReopenButton()
        {
            Operations.ClickReopenButton();
        }

        public void ClickSubmitCheckAll()
        {
            Operations.ClickSubmitCheckAll();
        }

        public void ClickApproveCheckAll()
        {
            Operations.ClickApproveCheckAll();
        }

        public void ClickReOpenCheckAll()
        {
            Operations.ClickReOpenCheckAll();
        }

        public void EnterReopenComment(string comment)
        {
            Operations.EnterReopenComment(comment);
        }

        public void EnterApproveComment(string comment)
        {
            Operations.EnterApproveComment(comment);
        }

        public void EnterSubmitComment(string comment)
        {
            Operations.EnterSubmitComment(comment);
        }

        public void ClickSubmitCancelButton()
        {
            Operations.ClickSubmitCancelButton();
        }

        public void ClickApproveCancelButton()
        {
            Operations.ClickApproveCancelButton();
        }

        public void ClickReopenCancelButton()
        {
            Operations.ClickReopenCancelButton();
        }

        public void ClickSubmitReviewsButton()
        {
            Operations.ClickSubmitReviewsButton();
        }

        public void ClickApproveReviewsButton()
        {
            Operations.ClickApproveReviewsButton();
        }

        public void ClickReopenReviewsButton()
        {
            Operations.ClickReopenReviewsButton();
        }

        public void ClickSubmitIndiviualCheckbox(int index)
        {
            Operations.ClickSubmitIndiviualCheckbox(index);
        }

        public void ClickApproveIndiviualCheckbox(int index)
        {
            Operations.ClickApproveIndiviualCheckbox(index);
        }

        public void ClickReopenIndiviualCheckbox(int index)
        {
            Operations.ClickReopenIndiviualCheckbox(index);
        }

        public int GetIndiviualApprovalCheckboxIndex(string name)
        {
            return Operations.GetIndiviualApprovalCheckboxIndex(name);
        }

        public void ClickNextPage()
        {
            Operations.ClickNextPage();
        }

        public bool IsMeritInEligible()
        {
            return Operations.IsMeritInEligible();
        }

        public bool IsPromotionInEligible()
        {
            return Operations.IsPromotionInEligible();
        }

        public bool IsAdjustmentInEligible()
        {
            return Operations.IsAdjustmentInEligible();
        }

        public bool IsLumpSumInEligible()
        {
            return Operations.IsLumpSumInEligible();
        }

        public string GetSalaryMin()
        {
            return Operations.GetSalaryMin();
        }

        public string GetProrationFactor()
        {
            return Operations.GetProrationFactor();
        }
        #endregion
    }
}
