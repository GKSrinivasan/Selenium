﻿using Laserbeam.QA.Automation.HR.Common.Elements;
using Laserbeam.QA.Automation.HR.Common.Operations;
using OpenQA.Selenium;

namespace Laserbeam.QA.Automation.HR.Common.Pages
{
    public class DashboardPage
    {
        #region Fields
        private readonly IWebDriver browser;
        #endregion

        #region Constructor
        public DashboardPage(IWebDriver m_browser)
        {
            browser = m_browser;
        }
        #endregion

        #region Property
        public DashboardElements Elements
        {
            get
            {
                return new DashboardElements(browser);
            }
        }

        public DashboardOperations Operations
        {
            get
            {
                return new DashboardOperations(Elements);
            }
        }
        #endregion

        #region DashboardActions
        public IWebElement ClickAdministrationLink()
        {
            return Operations.ClickAdministrationLink();
        }

        public IWebElement ClickRewardsLink()
        {
            return Operations.ClickRewardLink();
        }

        public string ClickHomeLink()
        {
            return Operations.ClickHomeLink();
        }

        public string ClickWorkforceTile()
        {
            return Operations.ClickWorkforceTile();
        }

        public string ClickExchangeRateTile()
        {
            return Operations.ClickExchangeRateTile();
        }

        public string ClickAccessControlTile()
        {
            return Operations.ClickAccessControlTile();
        }

        public string ClickWorkflowTile()
        {
            return Operations.ClickWorkflowTile();
        }

        public string ClickRatingTile()
        {
            return Operations.ClickRatingTile();
        }

        public string ClickRulesTile()
        {
            return Operations.ClickRulesTile();
        }

        public string ClickBudgetPlanTile()
        {
            return Operations.ClickBudgetPlanTile();
        }

        public string ClickCommunicationTile()
        {
            return Operations.ClickCommunicationTile();
        }

        public string ClickCustomizeViewTile()
        {
            return Operations.ClickCustomizeViewTile();
        }

        public string ClickRewardsTile()
        {
            return Operations.ClickRewardsTile();
        }

        public string ClickAnalyticsLink()
        {
            return Operations.ClickAnalyticsLink();
        }

        public void ClickLogOut()
        {
            Operations.ClickLogOut();
        }
        #endregion
    }
}
