﻿using Laserbeam.QA.Automation.HR.Common.Elements;
using Laserbeam.QA.Automation.HR.Common.Operations;
using OpenQA.Selenium;

namespace Laserbeam.QA.Automation.HR.Common.Pages
{
    public class RulePage
    {
        #region Fields
        private readonly IWebDriver browser;
        #endregion

        #region Constructor
        public RulePage(IWebDriver m_browser)
        {
            browser = m_browser;
        }
        #endregion

        #region Property
        public RuleElements Elements
        {
            get
            {
                return new RuleElements(browser);
            }
        }

        public RuleOperations Operations
        {
            get
            {
                return new RuleOperations(Elements);
            }
        }
        #endregion

        #region RuleActions
        public IWebElement IsMeritChecked()
        {
            return Operations.IsMeritChecked();
        }

        public IWebElement IsPerformanceRatingChecked()
        {
            return Operations.IsPerformanceRatingChecked();
        }

        public IWebElement IsLumpSumChecked()
        {
            return Operations.IsLumpSumChecked();
        }

        public IWebElement IsPromotionChecked()
        {
            return Operations.IsPromotionChecked();
        }

        public IWebElement IsAdjustmentChecked()
        {
            return Operations.IsAdjustmentChecked();
        }

        public IWebElement IsWorkFlowChecked()
        {
            return Operations.IsWorkFlowChecked();
        }

        public IWebElement IsMultiCurrencyChecked()
        {
            return Operations.IsMultiCurrencyChecked();
        }

        public void ClickMeritTile()
        {
            Operations.ClickMeritTile();
        }

        public void ClickPerformanceRatingTile()
        {
            Operations.ClickPerformanceRatingTile();
        }

        public void ClickLumpSumTile()
        {
            Operations.ClickLumpSumTile();
        }

        public void ClickPromotionTile()
        {
            Operations.ClickPromotionTile();
        }

        public void ClickAdjustmentTile()
        {
            Operations.ClickAdjustmentTile();
        }

        public void ClickWorkflowTile()
        {
            Operations.ClickWorkflowTile();
        }

        public void ClickMultiCurrencyTile()
        {
            Operations.ClickMultiCurrencyTile();
        }

        public string ClickSaveButton()
        {
            return Operations.ClickSaveButton();
        }

        public void ChangeCurrentWorkYear(string year)
        {
            Operations.ChangeCurrentWorkYear(year);
        }

        public void ChangeEmailAddress(string year)
        {
            Operations.ChangeEmailAddress(year);
        }

        public void SelectLoggedUserCurrency()
        {
            Operations.SelectLoggedUserCurrency();
        }

        public void SelectBaseCurrency()
        {
            Operations.SelectBaseCurrency();
        }

        public void EnablePermanceRating(bool enable)
        {
            Operations.EnablePermanceRating(enable);
        }

        public void EnableTCC(bool enable)
        {
            Operations.EnableTCC(enable);
        }

        public void EnableAutoCalculateMerit(bool enable)
        {
            Operations.EnableAutoCalculateMerit(enable);
        }

        public void EnableProrateMerit(bool enable)
        {
            Operations.EnableProrateMerit(enable);
        }

        public void EnableEitherMeritOrLumpSum(bool enable)
        {
            Operations.EnableEitherMeritOrLumpSum(enable);
        }

        public void EnableReCalculateMerit(bool enable)
        {
            Operations.EnableReCalculateMerit(enable);
        }

        public void EnableAutoCalculateLumpSum(bool enable)
        {
            Operations.EnableAutoCalculateLumpSum(enable);
        }

        public void EnableTurnOffLumpSule(bool enable)
        {
            Operations.EnableTurnOffLumpSule(enable);
        }

        public void SelectAutoCalculateLump()
        {
            Operations.SelectAutoCalculateLump();
        }

        public void SelectDoNotAutoCalculateLump()
        {
            Operations.SelectDoNotAutoCalculateLump();
        }

        public void EnterLumpSumPCT(string pct)
        {
            Operations.EnterLumpSumPCT(pct);
        }

        public void EnterLumpSumAmt(string amt)
        {
            Operations.EnterLumpSumAmt(amt);
        }

        public void DecisionCollaboration(bool HardNoExceedGuideline, bool HardExceedGuideline, bool SoftStopMandatory, bool SoftStopNoMandatory)
        {
            Operations.DecisionCollaboration(HardNoExceedGuideline, HardExceedGuideline, SoftStopMandatory, SoftStopNoMandatory);
        }

        public void SetMeritRoundingRule(string roundingPct,string roundingHourly,string roundingAnnual,string decimalPct,string decimalHourly,string decimalAnnual)
        {
            Operations.SelectMeritPercentageRounding(roundingPct);
            Operations.SelectMeritHourlyRounding(roundingHourly);
            Operations.SelectMeritAnnualRounding(roundingAnnual);
            Operations.SelectMeritPercentageDecimal(decimalPct);
            Operations.SelectMeritHourlyDecimal(decimalHourly);
            Operations.SelectMeritAnnualDecimal(decimalAnnual);
        }

        public void SetLumpSumRoundingRule(string roundingPct, string roundingHourly, string roundingAnnual, string decimalPct, string decimalHourly, string decimalAnnual)
        {
            Operations.SelectLumpSumPercentageRounding(roundingPct);
            Operations.SelectLumpSumHourlyRounding(roundingHourly);
            Operations.SelectLumpSumAnnualRounding(roundingAnnual);
            Operations.SelectLumpSumPercentageDecimal(decimalPct);
            Operations.SelectLumpSumHourlyDecimal(decimalHourly);
            Operations.SelectLumpSumAnnualDecimal(decimalAnnual);
        }

        public void SetAdjustmentRoundingRule(string roundingPct, string roundingHourly, string roundingAnnual, string decimalPct, string decimalHourly, string decimalAnnual)
        {
            Operations.SelectAdjustmentPercentageRounding(roundingPct);
            Operations.SelectAdjustmentHourlyRounding(roundingHourly);
            Operations.SelectAdjustmentAnnualRounding(roundingAnnual);
            Operations.SelectAdjustmentPercentageDecimal(decimalPct);
            Operations.SelectAdjustmentHourlyDecimal(decimalHourly);
            Operations.SelectAdjustmentAnnualDecimal(decimalAnnual);
        }

        public void SetCompRatioRoundingRule(string roundingPct, string roundingHourly, string roundingAnnual, string decimalPct, string decimalHourly, string decimalAnnual)
        {
            Operations.SelectCompRatioPercentageRounding(roundingPct);
            Operations.SelectCompRatioHourlyRounding(roundingHourly);
            Operations.SelectCompRatioAnnualRounding(roundingAnnual);
            Operations.SelectCompRatioPercentageDecimal(decimalPct);
            Operations.SelectCompRatioHourlyDecimal(decimalHourly);
            Operations.SelectCompRatioAnnualDecimal(decimalAnnual);
        }

        public void SetPromotionRoundingRule(string roundingPct, string roundingHourly, string roundingAnnual, string decimalPct, string decimalHourly, string decimalAnnual)
        {
            Operations.SelectPromotionPercentageRounding(roundingPct);
            Operations.SelectPromotionHourlyRounding(roundingHourly);
            Operations.SelectPromotionAnnualRounding(roundingAnnual);
            Operations.SelectPromotionPercentageDecimal(decimalPct);
            Operations.SelectPromotionHourlyDecimal(decimalHourly);
            Operations.SelectPromotionAnnualDecimal(decimalAnnual);
        }

        public void SetNewSalaryRoundingRule(string roundingPct, string roundingHourly, string roundingAnnual, string decimalPct, string decimalHourly, string decimalAnnual)
        {
            Operations.SelectNewSalaryPercentageRounding(roundingPct);
            Operations.SelectNewSalaryHourlyRounding(roundingHourly);
            Operations.SelectNewSalaryAnnualRounding(roundingAnnual);
            Operations.SelectNewSalaryPercentageDecimal(decimalPct);
            Operations.SelectNewSalaryHourlyDecimal(decimalHourly);
            Operations.SelectNewSalaryAnnualDecimal(decimalAnnual);
        }

        public void SetPasswordLength(string length)
        {
            Operations.SelectPasswordLength(length);
        }

        public void SetUserNameFormat(string length)
        {
            Operations.SelectUserNameFormat(length);
        }

        public void SetEmployeeNameFormat(string length)
        {
            Operations.SelectEmployeeNameFormat(length);
        }

        public void SetEmployeeNameSortOrder(string length)
        {
            Operations.SelectEmployeeNameSortOrder(length);
        }

        public void SetDateFormat(string length)
        {
            Operations.SelectDateFormat(length);
        }

        public void SetDisplayCurrencyType(bool currenycCode)
        {
            Operations.SetDisplayCurrencyType(currenycCode);
        }

        public void SelectProrateMethod(string type)
        {
            Operations.SelectProrateMethod(type);
        }

        public void EnterProrateCalendarDuration(string value)
        {
            Operations.EnterProrateCalendarDuration(value);
        }

        public void EnterProrateEmployeeWorkedInMonth(string value)
        {
            Operations.EnterProrateEmployeeWorkedInMonth(value);
        }

        public void ClickProrateRuleForBudgetCheckBox()
        {
            Operations.ClickProrateRuleForBudgetCheckBox();
        }

        public void ChooseProrateStartDate(string year, string month, string day)
        {
            Operations.ChooseProrateStartDate(year, month, day);
        }

        public void ChooseProrateEndDate(string year, string month, string day)
        {
            Operations.ChooseProrateEndDate(year, month, day);
        }
        #endregion
    }
}
