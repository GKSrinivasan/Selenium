﻿using Laserbeam.QA.Automation.HR.Common.Elements;
using Laserbeam.QA.Automation.HR.Common.Operations;
using OpenQA.Selenium;

namespace Laserbeam.QA.Automation.HR.Common.Pages
{
    public class LoginPage
    {
        #region Fields
        private readonly IWebDriver browser;
        #endregion

        #region Constructor
        public LoginPage(IWebDriver m_browser)
        {
            browser = m_browser;
        }
        #endregion

        #region Property
        public LoginElements Elements
        {
            get
            {
                return new LoginElements(browser);
            }
        }

        public LoginOperations Operations
        {
            get
            {
                return new LoginOperations(Elements);
            }
        }
        #endregion

        #region LoginActions
        public string Login(string userName, string password)
        {
            return Operations.Login(userName, password);
        }

        public string GetMessage()
        {
            return Operations.GetMessage();
        }
        #endregion
    }
}
