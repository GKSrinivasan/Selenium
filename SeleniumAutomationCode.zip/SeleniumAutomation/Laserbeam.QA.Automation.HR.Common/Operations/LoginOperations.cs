﻿using Laserbeam.QA.Automation.HR.Common.Elements;
using OpenQA.Selenium;
using System.Threading;

namespace Laserbeam.QA.Automation.HR.Common.Operations
{
    public class LoginOperations
    {
        #region Fields
        protected readonly LoginElements loginElements;
        #endregion

        #region Constructor
        public LoginOperations(LoginElements LoginElements)
        {
            loginElements = LoginElements;
        }
        #endregion

        #region LoginOperations
        public string Login(string userName, string password)
        {
            loginElements.UserNameTextBox.SendKeys(userName);
            loginElements.UserPasswordTextBox.SendKeys(password);
            loginElements.LoginButton.SendKeys(Keys.Enter);
            Thread.Sleep(5000);
            return loginElements.CurrentURL;
        }

        public string GetMessage()
        {
            return loginElements.LoginErrorMessage.Text;
        }
        #endregion
    }
}
