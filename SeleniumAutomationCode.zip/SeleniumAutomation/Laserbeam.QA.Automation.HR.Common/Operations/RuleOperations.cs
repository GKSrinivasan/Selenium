﻿using Laserbeam.QA.Automation.HR.Common.Elements;
using OpenQA.Selenium;
using System.Threading;

namespace Laserbeam.QA.Automation.HR.Common.Operations
{
    public class RuleOperations
    {
        #region Fields
        protected readonly RuleElements ruleElements;
        #endregion

        #region Constructor
        public RuleOperations(RuleElements RuleElements)
        {
            ruleElements = RuleElements;
        }
        #endregion

        #region RuleOperations
        public IWebElement IsMeritChecked()
        {
            IWebElement test = ruleElements.IsMeritChecked;
            return test;
        }

        public IWebElement IsPerformanceRatingChecked()
        {
            IWebElement test = ruleElements.IsPerformanceRatingChecked;
            return test;
        }

        public IWebElement IsLumpSumChecked()
        {
            IWebElement test = ruleElements.IsLumpSumChecked;
            return test;
        }

        public IWebElement IsPromotionChecked()
        {
            IWebElement test = ruleElements.IsPromotionChecked;
            return test;
        }

        public IWebElement IsAdjustmentChecked()
        {
            IWebElement test = ruleElements.IsAdjustmentChecked;
            return test;
        }

        public IWebElement IsWorkFlowChecked()
        {
            IWebElement test = ruleElements.IsWorkFlowChecked;
            return test;
        }

        public IWebElement IsMultiCurrencyChecked()
        {
            IWebElement test = ruleElements.IsMultiCurrencyChecked;
            return test;
        }

        public void ClickMeritTile()
        {
            ruleElements.MeritTile.Click();
        }

        public void ClickPerformanceRatingTile()
        {
            ruleElements.PerformanceRatingTile.Click();
        }

        public void ClickLumpSumTile()
        {
            ruleElements.LumpSumTile.Click();
        }

        public void ClickPromotionTile()
        {
            ruleElements.PromotionTile.Click();
        }

        public void ClickAdjustmentTile()
        {
            ruleElements.AdjustmentTile.Click();
        }

        public void ClickWorkflowTile()
        {
            ruleElements.WorkflowTile.Click();
        }

        public void ClickMultiCurrencyTile()
        {
            ruleElements.MultiCurrencyTile.Click();
        }

        public string ClickSaveButton()
        {
            ruleElements.SaveButton.Click();
            Thread.Sleep(2000);
            return ruleElements.MessageTile.Text;
        }

        public void ChangeCurrentWorkYear(string year)
        {
            ruleElements.CurrentYearTextBox.Clear();
            ruleElements.CurrentYearTextBox.SendKeys(year);
            ruleElements.CurrentYearTextBox.SendKeys(Keys.Tab);
        }

        public void ChangeEmailAddress(string emailID)
        {
            ruleElements.EmailAddressTextBox.Clear();
            ruleElements.EmailAddressTextBox.SendKeys(emailID);
            ruleElements.EmailAddressTextBox.SendKeys(Keys.Tab);
        }

        public void SelectLoggedUserCurrency()
        {
            ruleElements.LoggedUserCurrencyButton.Click();
        }

        public void SelectBaseCurrency()
        {
            ruleElements.BaseCurrencyButton.Click();
        }

        public void EnablePermanceRating(bool enable)
        {
            if(enable)
                ruleElements.EnablePerformanceRating.Click();
            else
                ruleElements.DisablePerformanceRating.Click();
        }

        public void EnableTCC(bool enable)
        {
            if(enable)
                ruleElements.EnableTCC.Click();
            else
                ruleElements.DisableTCC.Click();
        }

        public void EnableAutoCalculateMerit(bool enable)
        {
            if(enable)
                ruleElements.EnableAutoCalculateMerit.Click();
            else
                ruleElements.DisableAutoCalculateMerit.Click();
        }

        public void EnableProrateMerit(bool enable)
        {
            if(enable)
                ruleElements.EnableProrateMerit.Click();
            else
                ruleElements.DisableProrateMerit.Click();
        }

        public void EnableEitherMeritOrLumpSum(bool enable)
        {
            if (enable)
                ruleElements.EnableEitherMeritOrLumpSum.Click();
            else
                ruleElements.DiasbleEitherMeritOrLumpSum.Click();
        }

        public void EnableReCalculateMerit(bool enable)
        {
            if (enable)
                ruleElements.EnableRecalculate.Click();
            else
                ruleElements.DiasbleRecalculate.Click();
        }

        public void EnableAutoCalculateLumpSum(bool enable)
        {
            if (enable)
                ruleElements.EnableAutoCalculateLumpSum.Click();
            else
                ruleElements.DiasbleAutoCalculateLumpSum.Click();
        }

        public void EnableTurnOffLumpSule(bool enable)
        {
            if (enable)
                ruleElements.EnableTurnOffLumpSum.Click();
            else
                ruleElements.DiasbleTurnOffLumpSum.Click();
        }

        public void SelectAutoCalculateLump()
        {
            ruleElements.AutoCalculateLumpSumCheckbox.Click();
            Thread.Sleep(1000);
        }

        public void SelectDoNotAutoCalculateLump()
        {
            ruleElements.DonotAutoCalculateLumpSumCheckbox.Click();
            Thread.Sleep(1000);
        }

        public void EnterLumpSumPCT(string pct)
        {
            ruleElements.LumpPCTTextBox.Clear();
            ruleElements.LumpPCTTextBox.SendKeys(pct);
            ruleElements.LumpPCTTextBox.SendKeys(Keys.Tab);
        }

        public void EnterLumpSumAmt(string amt)
        {
            ruleElements.LumpAmtTextBox.Clear();
            ruleElements.LumpAmtTextBox.SendKeys(amt);
            ruleElements.LumpAmtTextBox.SendKeys(Keys.Tab);
        }

        public void DecisionCollaboration(bool HardNoExceedGuideline,bool HardExceedGuideline,bool SoftStopMandatory,bool SoftStopNoMandatory)
        {
            if (HardNoExceedGuideline)
                ruleElements.ManagerCannotProvideIncrease.Click();
            else if (HardExceedGuideline)
                ruleElements.ManagerCanProvideIncreaseWithInBudget.Click();
            else if (SoftStopMandatory)
                ruleElements.ManagerCanProvideIncreaseWithJustification.Click();
            else if (SoftStopNoMandatory)
                ruleElements.ManagerCanProvideIncreaseWithoutJustification.Click();
        }

        public void SelectMeritPercentageRounding(string value)
        {
            ruleElements.MeritPercentageRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.MeritPercentageRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectLumpSumPercentageRounding(string value)
        {
            ruleElements.LumpSumPercentageRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.LumpSumPercentageRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectAdjustmentPercentageRounding(string value)
        {
            ruleElements.AdjustmentPercentageRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.AdjustmentPercentageRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectCompRatioPercentageRounding(string value)
        {
            ruleElements.CompRatioPercentageRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.CompRatioPercentageRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectPromotionPercentageRounding(string value)
        {
            ruleElements.PromotionPercentageRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.PromotionPercentageRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectNewSalaryPercentageRounding(string value)
        {
            ruleElements.NewSalaryPercentageRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.NewSalaryPercentageRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectMeritHourlyRounding(string value)
        {
            ruleElements.MeritHourlyRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.MeritHourlyRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectLumpSumHourlyRounding(string value)
        {
            ruleElements.LumpSumHourlyRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.LumpSumHourlyRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectAdjustmentHourlyRounding(string value)
        {
            ruleElements.AdjustmentHourlyRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.AdjustmentHourlyRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectCompRatioHourlyRounding(string value)
        {
            ruleElements.CompRatioHourlyRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.CompRatioHourlyRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectPromotionHourlyRounding(string value)
        {
            ruleElements.PromotionHourlyRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.PromotionHourlyRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectNewSalaryHourlyRounding(string value)
        {
            ruleElements.NewSalaryHourlyRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.NewSalaryHourlyRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectMeritAnnualRounding(string value)
        {
            ruleElements.MeritAnnualRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.MeritAnnualRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectLumpSumAnnualRounding(string value)
        {
            ruleElements.LumpSumAnnualRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.LumpSumAnnualRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectAdjustmentAnnualRounding(string value)
        {
            ruleElements.AdjustmentAnnualRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.AdjustmentAnnualRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectCompRatioAnnualRounding(string value)
        {
            ruleElements.CompRatioAnnualRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.CompRatioAnnualRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectPromotionAnnualRounding(string value)
        {
            ruleElements.PromotionAnnualRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.PromotionAnnualRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectNewSalaryAnnualRounding(string value)
        {
            ruleElements.NewSalaryAnnualRoundingDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.NewSalaryAnnualRoundingDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectMeritPercentageDecimal(string value)
        {
            ruleElements.MeritPercentageDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.MeritPercentageDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectLumpSumPercentageDecimal(string value)
        {
            ruleElements.LumpSumPercentageDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.LumpSumPercentageDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectAdjustmentPercentageDecimal(string value)
        {
            ruleElements.AdjustmentPercentageDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.AdjustmentPercentageDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectCompRatioPercentageDecimal(string value)
        {
            ruleElements.CompRatioPercentageDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.CompRatioPercentageDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectPromotionPercentageDecimal(string value)
        {
            ruleElements.PromotionPercentageDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.PromotionPercentageDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectNewSalaryPercentageDecimal(string value)
        {
            ruleElements.NewSalaryPercentageDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.NewSalaryPercentageDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectMeritHourlyDecimal(string value)
        {
            ruleElements.MeritHourlyDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.MeritHourlyDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectLumpSumHourlyDecimal(string value)
        {
            ruleElements.LumpSumHourlyDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.LumpSumHourlyDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectAdjustmentHourlyDecimal(string value)
        {
            ruleElements.AdjustmentHourlyDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.AdjustmentHourlyDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectCompRatioHourlyDecimal(string value)
        {
            ruleElements.CompRatioHourlyDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.CompRatioHourlyDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectPromotionHourlyDecimal(string value)
        {
            ruleElements.PromotionHourlyDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.PromotionHourlyDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectNewSalaryHourlyDecimal(string value)
        {
            ruleElements.NewSalaryHourlyDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.NewSalaryHourlyDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectMeritAnnualDecimal(string value)
        {
            ruleElements.MeritAnnualDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.MeritAnnualDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectLumpSumAnnualDecimal(string value)
        {
            ruleElements.LumpSumAnnualDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.LumpSumAnnualDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectAdjustmentAnnualDecimal(string value)
        {
            ruleElements.AdjustmentAnnualDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.AdjustmentAnnualDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectCompRatioAnnualDecimal(string value)
        {
            ruleElements.CompRatioAnnualDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.CompRatioAnnualDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectPromotionAnnualDecimal(string value)
        {
            ruleElements.PromotionAnnualDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.PromotionAnnualDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectNewSalaryAnnualDecimal(string value)
        {
            ruleElements.NewSalaryAnnualDecimalDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.NewSalaryAnnualDecimalDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectPasswordLength(string value)
        {
            ruleElements.PasswordLengthDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.PasswordLengthDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectUserNameFormat(string value)
        {
            ruleElements.UserNameFormatDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.UserNameFormatDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectEmployeeNameFormat(string value)
        {
            ruleElements.EmployeeNameFormatDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.EmployeeNameFormatDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectEmployeeNameSortOrder(string value)
        {
            ruleElements.EmployeeNameSortOrderDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.EmployeeNameSortOrderDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SelectDateFormat(string value)
        {
            ruleElements.DateFormatDropdown.Click();
            Thread.Sleep(1000);
            ruleElements.DateFormatDropdownValue(value).Click();
            Thread.Sleep(1000);
        }

        public void SetDisplayCurrencyType(bool currenycCode)
        {
            if (currenycCode)
                ruleElements.CurrencyCode.Click();
            else
                ruleElements.CurrencySymbol.Click();
        }

        public void SelectProrateMethod(string type)
        {
            if (type == "Daily")
                ruleElements.ProrateMethodDailyButton.Click();
            else if (type == "Weekly")
                ruleElements.ProrateMethodWeeklyButton.Click();
            else if (type == "Monthly")
                ruleElements.ProrateMethodMonthlyButton.Click();
        }

        public void EnterProrateCalendarDuration(string value)
        {
            ruleElements.ProrateCalendarDurationTextBox.Clear();
            ruleElements.ProrateCalendarDurationTextBox.SendKeys(value);
            ruleElements.ProrateCalendarDurationTextBox.SendKeys(Keys.Tab);
        }

        public void EnterProrateEmployeeWorkedInMonth(string value)
        {
            ruleElements.ProrateEmployeeWorkedInMonthTextBox.Clear();
            ruleElements.ProrateEmployeeWorkedInMonthTextBox.SendKeys(value);
            ruleElements.ProrateEmployeeWorkedInMonthTextBox.SendKeys(Keys.Tab);
        }

        public void ClickProrateRuleForBudgetCheckBox()
        {
            ruleElements.ProrateRuleForBudgetCheckBox.Click();
        }

        public void ChooseProrateStartDate(string year,string month,string day)
        {
            ruleElements.ProrateDatePickerSelectIcons[1].Click();
            Thread.Sleep(1000);
            ruleElements.ProrateStartDateTile.Click();
            Thread.Sleep(1000);
            ruleElements.ProrateStartDateTile.Click();
            Thread.Sleep(1000);
            ruleElements.ChooseProrateStartDateYear(year).Click();
            Thread.Sleep(1000);
            ruleElements.ChooseProrateStartDateMonth(month).Click();
            Thread.Sleep(1000);
            ruleElements.ChooseProrateStartDateDay(day).Click();
            Thread.Sleep(1000);
        }

        public void ChooseProrateEndDate(string year, string month, string day)
        {
            ruleElements.ProrateDatePickerSelectIcons[2].Click();
            Thread.Sleep(1000);
            ruleElements.ProrateEndDateTile.Click();
            Thread.Sleep(1000);
            ruleElements.ProrateEndDateTile.Click();
            Thread.Sleep(1000);
            ruleElements.ChooseProrateEndDateYear(year).Click();
            Thread.Sleep(1000);
            ruleElements.ChooseProrateEndDateMonth(month).Click();
            Thread.Sleep(1000);
            ruleElements.ChooseProrateEndDateDay(day).Click();
            Thread.Sleep(1000);
        }
        #endregion
    }
}
