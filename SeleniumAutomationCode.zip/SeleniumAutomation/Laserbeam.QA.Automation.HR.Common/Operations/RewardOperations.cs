﻿using Laserbeam.QA.Automation.HR.Common.Elements;
using OpenQA.Selenium;
using System;
using System.Collections.ObjectModel;
using System.Threading;

namespace Laserbeam.QA.Automation.HR.Common.Operations
{
    public class RewardOperations
    {
        #region Fields
        protected readonly RewardElements rewardElements;
        #endregion

        #region Constructor
        public RewardOperations(RewardElements RewardElements)
        {
            rewardElements = RewardElements;
        }
        #endregion

        #region RewardsOperation
        public ReadOnlyCollection<IWebElement> GetLockedGridContent()
        {
            return rewardElements.LockedGridContent;
        }

        public void ClickManagerTree()
        {
            rewardElements.CorporateTeam.Click();
        }

        public string ChangeManager(string managerName)
        {
            var manager=rewardElements.FindManagerName(managerName);
            Thread.Sleep(3000);
            manager.Click();
            Thread.Sleep(5000);
            return rewardElements.CorporateTeam.Text;
        }

        public void InputMeritPct(string pct,int index)
        {
            rewardElements.MeritPCTTextBox[index].Clear();
            rewardElements.MeritPCTTextBox[index].SendKeys(""+pct);
            rewardElements.MeritPCTTextBox[index].SendKeys(Keys.Tab);
            Thread.Sleep(3000);
        }

        public void InputMeritAmt(string pct, int index)
        {
            rewardElements.MeritAmtTextBox[index].Clear();
            rewardElements.MeritAmtTextBox[index].SendKeys("" + pct);
            rewardElements.MeritAmtTextBox[index].SendKeys(Keys.Tab);
            Thread.Sleep(3000);
        }

        public string GetMeritAmt(int index)
        {
            return rewardElements.MeritAmtTextBox[index].GetAttribute("value");
        }

        public string GetMeritPct(int index)
        {
            return rewardElements.MeritPCTTextBox[index].GetAttribute("value");
        }

        public string GetNewSalaryLocal(int index)
        {
            return rewardElements.NewSalaryLocal[index].Text;
        }

        public string ClickSaveButton()
        {
            rewardElements.RewardsSaveButton.Click();
            Thread.Sleep(2000);
            return rewardElements.MessageTile.Text;
        }

        public string GetBudgetAmt()
        {
            return rewardElements.RewardsBudgetAmt.Text;
        }

        public string GetBudgetPct()
        {
            return rewardElements.RewardsBudgetPct.Text;
        }

        public string GetBalanceAmt()
        {
            return rewardElements.RewardsBalanceAmt.Text;
        }

        public string GetBalancePct()
        {
            return rewardElements.RewardsBalancePct.Text;
        }    
        
        public void ClickPromotion(int index)
        {
            rewardElements.PromotionLink[index].Click();
            Thread.Sleep(2000);
        }

        public void InputPromotionTitlt(string title)
        {
            rewardElements.PromotionTextBox.SendKeys(title);
        }

        public void InputPromotionComment(string comment)
        {
            rewardElements.PromotionCommentBox.SendKeys(comment);
        }

        public void ClickAddPromotionCommentButton()
        {
            rewardElements.AddPromotionCommentButton.Click();
        }

        public void SelectPerformanceRating(int index,string rating)
        {
            rewardElements.PerfRatingDropdown[index].Click();
            Thread.Sleep(1500);
            rewardElements.PerfRatingDropdownValue(rating)[index].Click();
            Thread.Sleep(1500);
        }

        public string GetNewCompaRatioMin(int index)
        {
            return rewardElements.NewCompRationMin[index].Text;
        }

        public string GetNewCompaRatioMax(int index)
        {
            return rewardElements.NewCompRationMax[index].Text;
        }

        public void ClickSpentSummaryLink()
        {
            rewardElements.SpentSummaryLink.Click();
            Thread.Sleep(2000);
        }

        public string SummaryMeritAmt()
        {
            return rewardElements.SummaryMeritSpentAmt.Text;
        }

        public string SummaryPromotionAmt()
        {
            return rewardElements.SummaryPromotionSpentAmt.Text;
        }

        public string SummaryLumpSumAmt()
        {
            return rewardElements.SummaryLumpSumSpentAmt.Text;
        }

        public string SummaryAdjustmentAmt()
        {
            return rewardElements.SummaryAdjustmentSpentAmt.Text;
        }

        public string SummaryRemainingAmt()
        {
            return rewardElements.SummaryRemainingAmt.Text;
        }

        public string SummarySpentAmt()
        {
            return rewardElements.SummarySpentAmt.Text;
        }

        public void ClickSpentSummaryClose()
        {
            rewardElements.SummaryCloseIcon.Click();
        }

        public void ClickRewardsFilterButton()
        {
            rewardElements.RewardsFilterButton.Click();
            Thread.Sleep(2500);
        }

        public void SelectFilterColumn(string columnValue)
        {
            rewardElements.FilterColumn.Click();
            Thread.Sleep(1500);
            rewardElements.FilterColumnValue(columnValue).Click();
            Thread.Sleep(1000);
        }

        public void SelectFilterOperation(string operationValue)
        {
            rewardElements.FilterOperation.Click();
            Thread.Sleep(1500);
            rewardElements.FilterOperationValue(operationValue).Click();
            Thread.Sleep(1000);
        }

        public void SetSearchText(string searchText)
        {
            rewardElements.FilterSearchTextBox.Clear();
            rewardElements.FilterSearchTextBox.SendKeys(searchText);
            rewardElements.FilterSearchTextBox.SendKeys(Keys.Tab);
        }

        public void ClickAddButton()
        {
            rewardElements.FilterClickToAddButton.Click();
        }

        public void ClickFilterApplyButton()
        {
            rewardElements.FilterApplyButton.Click();
            Thread.Sleep(5000);
        }

        public void ClickFilterCloseButton()
        {
            rewardElements.FilterCloseButton.Click();
            Thread.Sleep(3000);
        }

        public void OpenComentPopup(int index)
        {
            rewardElements.CommentLink[index].Click();
            Thread.Sleep(2000);
        }

        public void SelectGeneralCommentTab(int index)
        {
            rewardElements.GeneralCommentTab.Click();
            Thread.Sleep(2000);
        }

        public void SelectMeritCommentTab(int index)
        {
            rewardElements.MeritCommentTab.Click();
            Thread.Sleep(2000);
        }

        public void SelectPromotionCommentTab(int index)
        {
            rewardElements.PromotionCommentTab.Click();
            Thread.Sleep(2000);
        }

        public void SelectWorkFlowCommentTab(int index)
        {
            rewardElements.WorkflowCommentTab.Click();
            Thread.Sleep(2000);
        }

        public void ClcikCommentPopAddCommentButton()
        {
            rewardElements.CommentPopAddCommentButton.Click();
            Thread.Sleep(2000);
        }

        public void ClcikCommentPopCancelButton()
        {
            rewardElements.CommentPopCancelButton.Click();
            Thread.Sleep(2000);
        }

        public void EnterCommentPopComment(string comment)
        {
            rewardElements.CommentPopTextArea.SendKeys(comment);
        }

        public void ClickSubmitButton()
        {
            rewardElements.SubmitButton.Click();
            Thread.Sleep(2000);
        }

        public void ClickApproveButton()
        {
            rewardElements.ApproveButton.Click();
            Thread.Sleep(2000);
        }

        public void ClickReopenButton()
        {
            rewardElements.ReopenButton.Click();
            Thread.Sleep(2000);
        }

        public void ClickSubmitCheckAll()
        {
            rewardElements.SubmitCheckAll.Click();
        }

        public void ClickApproveCheckAll()
        {
            rewardElements.ApproveCheckAll.Click();
        }

        public void ClickReOpenCheckAll()
        {
            rewardElements.ReOpenCheckAll.Click();
        }

        public void EnterReopenComment(string comment)
        {
            rewardElements.ReopenCommentTextArea.SendKeys(comment);
        }

        public void EnterApproveComment(string comment)
        {
            rewardElements.ApproveCommentTextArea.SendKeys(comment);
        }

        public void EnterSubmitComment(string comment)
        {
            rewardElements.SubmitCommentTextArea.SendKeys(comment);
        }

        public void ClickSubmitCancelButton()
        {
            rewardElements.SubmitCancelButton.Click();
            Thread.Sleep(2000);
        }

        public void ClickApproveCancelButton()
        {
            rewardElements.ApproveCancelButton.Click();
            Thread.Sleep(2000);
        }

        public void ClickReopenCancelButton()
        {
            rewardElements.ReopenCancelButton.Click();
            Thread.Sleep(2000);
        }

        public void ClickSubmitReviewsButton()
        {
            rewardElements.SubmitReviewsButton.Click();
            Thread.Sleep(2000);
        }

        public void ClickApproveReviewsButton()
        {
            rewardElements.ApproveReviewsButton.Click();
            Thread.Sleep(2000);
        }

        public void ClickReopenReviewsButton()
        {
            rewardElements.ReopenReviewsButton.Click();
            Thread.Sleep(2000);
        }

        public void ClickSubmitIndiviualCheckbox(int index)
        {
            rewardElements.SubmitIndividualCheckBox[index].Click();
            Thread.Sleep(1000);
        }

        public void ClickApproveIndiviualCheckbox(int index)
        {
            rewardElements.ApproveIndividualCheckBox[index].Click();
            Thread.Sleep(1000);
        }

        public void ClickReopenIndiviualCheckbox(int index)
        {
            rewardElements.ReopenIndividualCheckBox[index].Click();
            Thread.Sleep(1000);
        }

        public int GetIndiviualApprovalCheckboxIndex(string name)
        {
            var approvalEmployees = rewardElements.ApprovalEmployees;
            int index = 0;int setIndex = 0;
            foreach (var item in approvalEmployees)
            {
                if (item.Text == name)
                    setIndex = index;
                index++;
            }
            return setIndex;            
        }

        public void ClickNextPage()
        {
            rewardElements.NextPageIcon.Click();
            Thread.Sleep(3000);
        }

        public bool IsMeritInEligible()
        {
            return rewardElements.MeritInEligible != null ? true : false;
        }

        public bool IsPromotionInEligible()
        {
            return rewardElements.PromotionInEligible != null ? true : false;
        }

        public bool IsAdjustmentInEligible()
        {
            return rewardElements.AdjustmentInEligible != null ? true : false;
        }

        public bool IsLumpSumInEligible()
        {
            return rewardElements.LumpSumInEligible != null ? true : false;
        }

        public string GetSalaryMin()
        {
            return rewardElements.SalaryMin.Text;
        }

        public string GetProrationFactor()
        {
            return rewardElements.ProrationFactor.Text;
        }
        #endregion
    }
}
