﻿using Laserbeam.QA.Automation.HR.Common.Elements;
using OpenQA.Selenium;
using System.Threading;

namespace Laserbeam.QA.Automation.HR.Common.Operations
{
    public class DashboardOperations
    {
        #region Fields
        protected readonly DashboardElements dashboardElements;
        #endregion

        #region Constructor
        public DashboardOperations(DashboardElements DashboardElements)
        {
            dashboardElements = DashboardElements;
        }
        #endregion

        #region DashboardOperations
        public string ClickHomeLink()
        {
            dashboardElements.HomeLink.SendKeys(Keys.Enter);
            Thread.Sleep(5000);
            return dashboardElements.CurrentURL;
        }

        public IWebElement ClickAdministrationLink()
        {
            dashboardElements.AdministrationLink.SendKeys(Keys.Enter);
            Thread.Sleep(1000);
            return dashboardElements.RulesTile;
        }

        public string ClickWorkforceTile()
        {
            dashboardElements.WorkforceTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public string ClickExchangeRateTile()
        {
            dashboardElements.ExchangeRateTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public string ClickAccessControlTile()
        {
            dashboardElements.AccessControlTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public string ClickWorkflowTile()
        {
            dashboardElements.WorkflowTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public string ClickRatingTile()
        {
            dashboardElements.RatingTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public string ClickRulesTile()
        {
            dashboardElements.RulesTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public string ClickBudgetPlanTile()
        {
            dashboardElements.BudgetPlanTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public string ClickCommunicationTile()
        {
            dashboardElements.CommunicationTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public string ClickCustomizeViewTile()
        {
            dashboardElements.CustomizeViewTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public IWebElement ClickRewardLink()
        {
            dashboardElements.RewardsLink.SendKeys(Keys.Enter);
            Thread.Sleep(1000);
            return dashboardElements.RewardsTile;
        }

        public string ClickRewardsTile()
        {
            dashboardElements.RewardsTile.Click();
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public string ClickAnalyticsLink()
        {
            dashboardElements.AnalyticsLink.SendKeys(Keys.Enter);
            Thread.Sleep(3000);
            return dashboardElements.CurrentURL;
        }

        public void ClickLogOut()
        {
            Thread.Sleep(5000);
            dashboardElements.Logout.Click();
        }

        #endregion
    }
}
