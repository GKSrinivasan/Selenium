﻿using Laserbeam.QA.Automation.HR.Common.Pages;
using OpenQA.Selenium;

namespace Laserbeam.QA.Automation.HR.Common.Common
{
    public class PageInitialize
    {
        #region Fields
        private readonly IWebDriver browser;
        #endregion

        #region Constructor
        public PageInitialize(IWebDriver m_browser)
        {
            browser = m_browser;
        }
        #endregion

        #region InvokePages
        public LoginPage LoginPage
        {
            get
            {
                return new LoginPage(browser);
            }
        }

        public DashboardPage DashboardPage
        {
            get
            {
                return new DashboardPage(browser);
            }
        }

        public RulePage RulePage
        {
            get
            {
                return new RulePage(browser);
            }
        }

        public RewardsPage RewardsPage
        {
            get
            {
                return new RewardsPage(browser);
            }
        }
        #endregion
    }
}
