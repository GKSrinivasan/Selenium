﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using Laserbeam.QA.Automation.HR.Common.Resources;

namespace Laserbeam.QA.Automation.HR.Common.Common
{
    public class BaseClass
    {
        #region Fields
        static IWebDriver browser;
        private PageInitialize m_PageManager;
        static string serverPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
        static string filePath = serverPath.Split(new[] { CommonResource.Bin }, StringSplitOptions.None)[0] + CommonResource.TestResultPath;
        #endregion

        #region LauchBrowser
        public void LaunchCompassLogin(string type, string url)
        {
            if (type.ToLower() == CommonResource.ChromeBrowser)
                browser = new ChromeDriver(Environment.CurrentDirectory.Split(new[] { CommonResource.TestCaseProject }, StringSplitOptions.None)[0] + CommonResource.ChromeDriver);
            browser.Manage().Window.Maximize();
            browser.Navigate().GoToUrl(url);            
        }        
        #endregion

        #region PageInitialize       
        public PageInitialize Pages
        {
            get
            {
                return m_PageManager = new PageInitialize(browser);
            }
        }
        #endregion        

        #region CloseBrowser
        public void BaseCleanUp(string testCaseID,string inputID,string result,string errorMessage="")
        {
            WriteToExcel(testCaseID, inputID, result, errorMessage);
            browser.Close();            
        }
        #endregion

        #region WriteResult
        private void WriteToExcel(string testCaseID, string inputID, string result, string errorMessage = "")
        {
            Excel.Application resultApp = new Excel.Application();
            Excel.Workbook resultWorkbook = resultApp.Workbooks.Open(filePath);
            Excel._Worksheet resultWorksheet = resultWorkbook.Sheets[1];
            Excel.Range resultRange = resultWorksheet.UsedRange;
            int resultRowCount = resultRange.Rows.Count;
            resultRange.Cells[resultRowCount + 1, 1] = testCaseID;
            resultRange.Cells[resultRowCount + 1, 2] = inputID;
            resultRange.Cells[resultRowCount + 1, 3] = result;
            resultRange.Cells[resultRowCount + 1, 4] = DateTime.Now.ToString();
            resultRange.Cells[resultRowCount + 1, 5] = errorMessage;
            resultRange.Cells[resultRowCount + 1, 6] = (errorMessage != "") ? DateTime.Now.ToString() : "";
            resultWorkbook.Save();
            resultWorkbook.Close();
            resultApp.Quit();
        }
        private void statusUpdate(string testCaseName, string input, string status, Exception e)
        {
            string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine + "Test Case   : " + testCaseName;
            message += Environment.NewLine + "Input Number: " + input;
            message += Environment.NewLine + "Test Result : " + status;
            if (e != null)
            {
                message += Environment.NewLine + "Error Message: " + e.Message;
            }
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            WriteResult(message);
        }
        private void WriteResult(string message)
        {
            string filePath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location).Split(new[] { "bin" }, StringSplitOptions.None)[0] + "TestResults\\TestResults.txt";
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(message);
                writer.Close();
            }
        }
        #endregion
    }
}
