﻿namespace Laserbeam.QA.Automation.HR.Common.Constants
{
    public enum CompensationComponents
    {
        SelectMerit = 1,
        DeselectMerit = 2,
        SelectPerformanceRating = 1,
        DeselectPerformanceRating = 2,
        SelectLumpSum = 1,
        DeselectLumpSum = 2,
        SelectPromotion = 1,
        DeselectPromotion = 2,
        SelectAdjustment = 1,
        DeselectAdjustment = 2,
        SelectWorkflow = 1,
        DeselectWorkflow = 2,
        SelectMultiCurrency = 1,
        DeselectMultiCurrency = 2
    }
}
