﻿using Laserbeam.QA.Automation.HR.Common.Resources;
using OpenQA.Selenium;

namespace Laserbeam.QA.Automation.HR.Common.Elements
{
    public class DashboardElements
    {
        #region Fields
        private readonly IWebDriver browser;
        #endregion

        #region Constructor
        public DashboardElements(IWebDriver m_browser)
        {
            browser = m_browser;
        }
        #endregion

        #region DashboardPropertyElements
        public string CurrentURL
        {
            get
            {
                return browser.Url;
            }
        }

        public IWebElement HomeLink
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.HomeLinkID));
            }
        }

        public IWebElement AdministrationLink
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.AdministrationLinkID));
            }
        }

        public IWebElement RewardsLink
        {
            get
            {
                return browser.FindElement(By.ClassName(DashboardResource.RewardsLinkClass));
            }
        }

        public IWebElement AnalyticsLink
        {
            get
            {
                return browser.FindElement(By.CssSelector(DashboardResource.AnaltyicsLinkCSS));
            }
        }

        public IWebElement WorkforceTile
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.WorkforceTileID));
            }
        }

        public IWebElement ExchangeRateTile
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.ExchangeRateTileID));
            }
        }

        public IWebElement AccessControlTile
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.AccessControlTileID));
            }
        }

        public IWebElement WorkflowTile
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.WorkflowTileID));
            }
        }

        public IWebElement RatingTile
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.RatingTileID));
            }
        }

        public IWebElement RulesTile
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.RulesTileID));
            }
        }

        public IWebElement BudgetPlanTile
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.BudgetPlanTileID));
            }
        }

        public IWebElement CommunicationTile
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.CommunicationTileID));
            }
        }

        public IWebElement CustomizeViewTile
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.CustomizeViewTileID));
            }
        }

        public IWebElement RewardsTile
        {
            get
            {
                return browser.FindElement(By.ClassName(DashboardResource.RewardsTileClass));
            }
        }

        public IWebElement Logout
        {
            get
            {
                return browser.FindElement(By.Id(DashboardResource.LogoutButtonID));
            }
        }
        #endregion
    }
}
