﻿using Laserbeam.QA.Automation.HR.Common.Resources;
using OpenQA.Selenium;
using System.Collections.ObjectModel;

namespace Laserbeam.QA.Automation.HR.Common.Elements
{
    public class RewardElements
    {
        #region Fields
        private readonly IWebDriver browser;
        #endregion

        #region Constructor
        public RewardElements(IWebDriver m_browser)
        {
            browser = m_browser;
        }
        #endregion

        #region RewardsPropertyElement
        public IWebElement CorporateTeam
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.CorporateTeamID));
            }
        }

        public IWebElement MyOrganizationBudgetTile
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.MyOrganizationBudgetTileXPath));
            }
        }

        public IWebElement DirectBudgetTile
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.MyOrganizationBudgetTileXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> LockedGridContent
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.LockedGridContent));
            }
        }

        public IWebElement RewardsSaveButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.RewardsSaveButtonID));
            }
        }

        public IWebElement MessageTile
        {
            get
            {
                return browser.FindElement(By.Id(CommonResource.MessageTileID));
            }
        }

        public IWebElement RewardsBudgetAmt
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.RewardsBudgetAmtXPath));
            }
        }

        public IWebElement RewardsBalanceAmt
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.RewardsBalanceAmtXPath));
            }
        }

        public IWebElement RewardsBudgetPct
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.RewardsBudgetPctXPath));
            }
        }

        public IWebElement RewardsBalancePct
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.RewardsBalancePctXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> MeritPCTTextBox
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.MeritPCTTextBoxXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> MeritAmtTextBox
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.MeritAmtTextBoxXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> NewSalaryLocal
        {
            get
            {
                return browser.FindElements(By.Id(RewardsResource.NewSalaryLocalID));
            }
        }

        public ReadOnlyCollection<IWebElement> PromotionLink
        {
            get
            {
                return browser.FindElements(By.Id(RewardsResource.NewSalaryLocalID));
            }
        }

        public IWebElement PromotionTextBox
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.PromotionTextBoxXPath));
            }
        }

        public IWebElement PromotionCommentBox
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.PromotionCommentBoxXPath));
            }
        }

        public IWebElement AddPromotionCommentButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.AddPromotionCommentButtonID));
            }
        }

        public ReadOnlyCollection<IWebElement> PromotionPCTTextBox
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.PromotionPCTTextBoxXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> PromotionAmtTextBox
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.PromotionAmtTextBoxXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> AdjustmentPCTTextBox
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.AdjustmentPCTTextBoxXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> AdjustmentAmtTextBox
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.AdjustmentAmtTextBoxXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> LumpSumPCTTextBox
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.LumpSumPCTTextBoxXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> LumpSumAmtTextBox
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.LumpSumAmtTextBoxXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> PerfRatingDropdown
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.PerfRatingDropdownXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> NewCompRationMin
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.NewCompRationMinXPath));
            }
        }

        public ReadOnlyCollection<IWebElement> NewCompRationMax
        {
            get
            {
                return browser.FindElements(By.XPath(RewardsResource.NewCompRationMaxXPath));
            }
        }

        public IWebElement SpentSummaryLink
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.SpentSummaryLinkXPath));
            }
        }

        public IWebElement SummaryMeritSpentAmt
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SummaryMeritSpentAmtID));
            }
        }

        public IWebElement SummaryPromotionSpentAmt
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SummaryPromotionSpentAmtID));
            }
        }

        public IWebElement SummaryLumpSumSpentAmt
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SummaryLumpSumSpentAmtID));
            }
        }

        public IWebElement SummaryAdjustmentSpentAmt
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SummaryAdjustmentSpentAmtID));
            }
        }

        public IWebElement SummaryRemainingAmt
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SummaryRemainingAmtID));
            }
        }

        public IWebElement SummarySpentAmt
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SummarySpentAmtID));
            }
        }

        public IWebElement SummaryCloseIcon
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.SummaryCloseIconXPath));
            }
        }

        public IWebElement RewardsFilterButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.RewardsFilterButtonID));
            }
        }

        public IWebElement FilterColumn
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.FilterColumnXPath));
            }
        }

        public IWebElement FilterOperation
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.FilterOperationXPath));
            }
        }

        public IWebElement FilterSearchTextBox
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.FilterSearchTextBoxID));
            }
        }

        public IWebElement FilterClickToAddButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.FilterClickToAddButtonID));
            }
        }

        public IWebElement FilterConditionTextArea
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.FilterConditionTextAreaID));
            }
        }

        public IWebElement FilterSortConditionTextArea
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.FilterSortConditionTextAreaID));
            }
        }

        public IWebElement FilterApplyButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.FilterApplyButtonID));
            }
        }

        public IWebElement FilterCloseButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.FilterCloseButtonID));
            }
        }

        public ReadOnlyCollection<IWebElement> CommentLink
        {
            get
            {
                return browser.FindElements(By.Id(RewardsResource.CommentLinkID));
            }
        }

        public IWebElement GeneralCommentTab
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.GeneralCommentTabID));
            }
        }

        public IWebElement MeritCommentTab
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.MeritCommentTabID));
            }
        }

        public IWebElement PromotionCommentTab
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.PromotionCommentTabID));
            }
        }

        public IWebElement WorkflowCommentTab
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.WorkflowCommentTabID));
            }
        }

        public IWebElement CommentPopAddCommentButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.CommentPopAddCommentButtonID));
            }
        }

        public IWebElement CommentPopCancelButton
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.CommentPopCancelButtonXPath));
            }
        }

        public IWebElement CommentPopTextArea
        {
            get
            {
                return browser.FindElement(By.XPath(RewardsResource.CommentPopCancelButtonXPath));
            }
        }

        public IWebElement SubmitButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SubmitButtonID));
            }
        }

        public IWebElement ApproveButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ApproveButtonID));
            }
        }

        public IWebElement ReopenButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ReopenButtonID));
            }
        }

        public IWebElement SubmitCheckAll
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SubmitCheckAllID));
            }
        }

        public IWebElement ApproveCheckAll
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ApproveCheckAllID));
            }
        }

        public IWebElement ReOpenCheckAll
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ReOpenCheckAllID));
            }
        }

        public IWebElement ReopenCommentTextArea
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ReopenCommentTextAreaID));
            }
        }

        public IWebElement ApproveCommentTextArea
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ApproveCommentTextAreaID));
            }
        }

        public IWebElement SubmitCommentTextArea
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SubmitCommentTextAreaID));
            }
        }

        public IWebElement SubmitCancelButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SubmitCancelButtonID));
            }
        }

        public IWebElement ApproveCancelButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ApproveCancelButtonID));
            }
        }

        public IWebElement ReopenCancelButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ReopenCancelButtonID));
            }
        }

        public IWebElement ReopenReviewsButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ReopenReviewsButtonID));
            }
        }

        public IWebElement ApproveReviewsButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ApproveReviewsButtonID));
            }
        }

        public IWebElement SubmitReviewsButton
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SubmitReviewsButtonID));
            }
        }

        public ReadOnlyCollection<IWebElement> SubmitIndividualCheckBox
        {
            get
            {
                return browser.FindElements(By.Id(RewardsResource.SubmitIndividualCheckBoxID));
            }
        }

        public ReadOnlyCollection<IWebElement> ApproveIndividualCheckBox
        {
            get
            {
                return browser.FindElements(By.Id(RewardsResource.ApproveIndividualCheckBoxID));
            }
        }

        public ReadOnlyCollection<IWebElement> ReopenIndividualCheckBox
        {
            get
            {
                return browser.FindElements(By.Id(RewardsResource.ReopenIndividualCheckBoxID));
            }
        }

        public ReadOnlyCollection<IWebElement> ApprovalEmployees
        {
            get
            {
                return browser.FindElements(By.ClassName(RewardsResource.ApprovalEmployeesClass));
            }
        }

        public IWebElement NextPageIcon
        {
            get
            {
                return browser.FindElement(By.ClassName(RewardsResource.NextPageIconClass));
            }
        }

        public IWebElement MeritInEligible
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.MeritInEligibleID));
            }
        }

        public IWebElement PromotionInEligible
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.PromotionInEligibleID));
            }
        }

        public IWebElement AdjustmentInEligible
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.AdjustmentInEligibleID));
            }
        }

        public IWebElement LumpSumInEligible
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.LumpSumInEligibleID));
            }
        }

        public IWebElement SalaryMin
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.SalaryMinID));
            }
        }

        public IWebElement ProrationFactor
        {
            get
            {
                return browser.FindElement(By.Id(RewardsResource.ProrationFactorID));
            }
        }

        #endregion

        #region RewardsMethodElement
        public IWebElement FindManagerName(string managerName)
        {
            return browser.FindElement(By.XPath(RewardsResource.FindManagerName1XPath + managerName + " " + RewardsResource.FindManagerName2XPath));
        }       

        public ReadOnlyCollection<IWebElement> PerfRatingDropdownValue(string text)
        {
            return browser.FindElements(By.XPath(RewardsResource.PerfRatingDropdownValue1XPath+text+RewardsResource.XPathClose));
        }

        public IWebElement FilterColumnValue(string value)
        {
            return browser.FindElement(By.XPath(RewardsResource.FilterColumnValue1XPath + value+ RewardsResource.XPathClose));
        }

        public IWebElement FilterOperationValue(string value)
        {
            return browser.FindElement(By.XPath(RewardsResource.FilterOperationValue1XPath + value + RewardsResource.XPathClose));
        }
        #endregion
    }
}
