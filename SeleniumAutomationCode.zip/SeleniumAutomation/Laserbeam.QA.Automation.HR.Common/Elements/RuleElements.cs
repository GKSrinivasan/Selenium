﻿using Laserbeam.QA.Automation.HR.Common.Resources;
using OpenQA.Selenium;
using System.Collections.ObjectModel;

namespace Laserbeam.QA.Automation.HR.Common.Elements
{
    public class RuleElements
    {
        #region Fields
        private readonly IWebDriver browser;
        #endregion

        #region Constructor
        public RuleElements(IWebDriver m_browser)
        {
            browser = m_browser;
        }
        #endregion

        #region RulePropertyElements
        public IWebElement CompensationComponents
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.CompensationComponentsXPath));
            }
        }

        public IWebElement GeneralConfiguration
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.GeneralConfigurationXPath));
            }
        }

        public IWebElement SetPerformanceratingAndMeritrule
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.SetPerformanceratingAndMeritruleXPath));
            }
        }

        public IWebElement SetLumpSumRule
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.SetLumpSumRuleXPath));
            }
        }

        public IWebElement DecisionCollaboration
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.DecisionCollaborationXPath));
            }
        }

        public IWebElement SetRoundingRule
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.SetRoundingRuleXPath));
            }
        }

        public IWebElement SetNameAndDateFormat
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.SetNameAndDateFormatXPath));
            }
        }

        public IWebElement MeritTile
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.MeritTileID));
            }
        }

        public IWebElement PerformanceRatingTile
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.PerformanceRatingTileID));
            }
        }

        public IWebElement LumpSumTile
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.LumpSumTileID));
            }
        }

        public IWebElement PromotionTile
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.PromotionTileID));
            }
        }

        public IWebElement AdjustmentTile
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.AdjustmentTileID));
            }
        }

        public IWebElement WorkflowTile
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.WorkflowTileID));
            }
        }

        public IWebElement MultiCurrencyTile
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.MultiCurrencyTileID));
            }
        }

        public IWebElement IsMeritChecked
        {
            get
            {
                try
                {
                    return browser.FindElement(By.XPath(RulesResource.IsMeritCheckedXPath));
                }
                catch
                {
                    return null;
                }
            }
        }

        public IWebElement IsPerformanceRatingChecked
        {
            get
            {
                try
                {
                    return browser.FindElement(By.XPath(RulesResource.IsPerformanceRatingCheckedXPath));
                }
                catch
                {
                    return null;
                }
            }
        }

        public IWebElement IsLumpSumChecked
        {
            get
            {
                try
                {
                    return browser.FindElement(By.XPath(RulesResource.IsLumpSumCheckedXPath));
                }
                catch
                {
                    return null;
                }
            }
        }

        public IWebElement IsPromotionChecked
        {
            get
            {
                try
                {
                    return browser.FindElement(By.XPath(RulesResource.IsPromotionCheckedXPath));
                }
                catch
                {
                    return null;
                }
            }
        }

        public IWebElement IsAdjustmentChecked
        {
            get
            {
                try
                {
                    return browser.FindElement(By.XPath(RulesResource.IsAdjustmentCheckedXPath));
                }
                catch
                {
                    return null;
                }
            }
        }

        public IWebElement IsWorkFlowChecked
        {
            get
            {
                try
                {
                    return browser.FindElement(By.XPath(RulesResource.IsWorkFlowCheckedXPath));
                }
                catch
                {
                    return null;
                }
            }
        }

        public IWebElement IsMultiCurrencyChecked
        {
            get
            {
                try
                {
                    return browser.FindElement(By.XPath(RulesResource.IsMultiCurrencyCheckedXPath));
                }
                catch
                {
                    return null;
                }
            }
        }

        public IWebElement SaveButton
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.SaveButtonID));
            }
        }

        public IWebElement MessageTile
        {
            get
            {
                return browser.FindElement(By.Id(CommonResource.MessageTileID));
            }
        }

        public IWebElement CurrentYearTextBox
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.CurrentYearTextBoxID));
            }
        }

        public IWebElement EmailAddressTextBox
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.EmailAddressTextBoxID));
            }
        }

        public IWebElement LoggedUserCurrencyButton
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.LoggedUserCurrencyButtonXPath));
            }
        }

        public IWebElement BaseCurrencyButton
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.BaseCurrencyButtonXPath));
            }
        }

        public IWebElement EnablePerformanceRating
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.EnablePerformanceRatingCSS));
            }
        }

        public IWebElement DisablePerformanceRating
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.DisablePerformanceRatingCSS));
            }
        }

        public IWebElement EnableTCC
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.EnableTCCCSS));
            }
        }

        public IWebElement DisableTCC
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.DisableTCCCSS));
            }
        }

        public IWebElement EnableAutoCalculateMerit
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.EnableAutoCalculateMeritCSS));
            }
        }

        public IWebElement DisableAutoCalculateMerit
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.DisableAutoCalculateMeritCSS));
            }
        }

        public IWebElement EnableProrateMerit
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.EnableProrateMeritCSS));
            }
        }

        public IWebElement DisableProrateMerit
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.DisableProrateMeritCSS));
            }
        }

        public IWebElement EnableEitherMeritOrLumpSum
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.EnableEitherMeritOrLumpSumCSS));
            }
        }

        public IWebElement DiasbleEitherMeritOrLumpSum
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.DiasbleEitherMeritOrLumpSumCSS));
            }
        }

        public IWebElement EnableRecalculate
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.EnableRecalculateCSS));
            }
        }

        public IWebElement DiasbleRecalculate
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.DiasbleRecalculateCSS));
            }
        }

        public IWebElement EnableAutoCalculateLumpSum
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.EnableAutoCalculateLumpSumCSS));
            }
        }

        public IWebElement DiasbleAutoCalculateLumpSum
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.DiasbleAutoCalculateLumpSumCSS));
            }
        }

        public IWebElement EnableTurnOffLumpSum
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.EnableTurnOffLumpSumCSS));
            }
        }

        public IWebElement DiasbleTurnOffLumpSum
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.DiasbleTurnOffLumpSumCSS));
            }
        }

        public IWebElement AutoCalculateLumpSumCheckbox
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.AutoCalculateLumpSumCheckboxCSS));
            }
        }

        public IWebElement DonotAutoCalculateLumpSumCheckbox
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.DonotAutoCalculateLumpSumCheckboxCSS));
            }
        }

        public IWebElement LumpPCTTextBox
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.LumpPCTTextBoxID));
            }
        }

        public IWebElement LumpAmtTextBox
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.LumpAmtTextBoxID));
            }
        }

        public IWebElement ManagerCannotProvideIncrease
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.ManagerCannotProvideIncreaseCSS));
            }
        }

        public IWebElement ManagerCanProvideIncreaseWithInBudget
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.ManagerCanProvideIncreaseWithInBudgetCSS));
            }
        }

        public IWebElement ManagerCanProvideIncreaseWithJustification
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.ManagerCanProvideIncreaseWithJustificationCSS));
            }
        }

        public IWebElement ManagerCanProvideIncreaseWithoutJustification
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.ManagerCanProvideIncreaseWithoutJustificationCSS));
            }
        }

        public IWebElement MeritPercentageRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.MeritPercentageRoundingDropdownXPath));
            }
        }

        public IWebElement LumpSumPercentageRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.LumpSumPercentageRoundingDropdownXPath));
            }
        }

        public IWebElement AdjustmentPercentageRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.AdjustmentPercentageRoundingDropdownXPath));
            }
        }

        public IWebElement CompRatioPercentageRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.CompRatioPercentageRoundingDropdownXPath));
            }
        }

        public IWebElement PromotionPercentageRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.PromotionPercentageRoundingDropdownXPath));
            }
        }

        public IWebElement NewSalaryPercentageRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.NewSalaryPercentageRoundingDropdownXPath));
            }
        }

        public IWebElement MeritHourlyRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.MeritHourlyRoundingDropdownXPath));
            }
        }

        public IWebElement LumpSumHourlyRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.LumpSumHourlyRoundingDropdownXPath));
            }
        }

        public IWebElement AdjustmentHourlyRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.AdjustmentHourlyRoundingDropdownXPath));
            }
        }

        public IWebElement CompRatioHourlyRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.CompRatioHourlyRoundingDropdownXPath));
            }
        }

        public IWebElement PromotionHourlyRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.PromotionHourlyRoundingDropdownXPath));
            }
        }

        public IWebElement NewSalaryHourlyRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.NewSalaryHourlyRoundingDropdownXPath));
            }
        }

        public IWebElement MeritAnnualRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.MeritAnnualRoundingDropdownXPath));
            }
        }

        public IWebElement LumpSumAnnualRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.LumpSumAnnualRoundingDropdownXPath));
            }
        }

        public IWebElement AdjustmentAnnualRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.AdjustmentAnnualRoundingDropdownXPath));
            }
        }

        public IWebElement CompRatioAnnualRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.CompRatioAnnualRoundingDropdownXPath));
            }
        }

        public IWebElement PromotionAnnualRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.PromotionAnnualRoundingDropdownXPath));
            }
        }

        public IWebElement NewSalaryAnnualRoundingDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.NewSalaryAnnualRoundingDropdownXPath));
            }
        }

        public IWebElement MeritPercentageDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.MeritPercentageDecimalDropdownXPath));
            }
        }

        public IWebElement LumpSumPercentageDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.LumpSumPercentageDecimalDropdownXPath));
            }
        }

        public IWebElement AdjustmentPercentageDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.AdjustmentPercentageDecimalDropdownXPath));
            }
        }

        public IWebElement CompRatioPercentageDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.CompRatioPercentageDecimalDropdownXPath));
            }
        }

        public IWebElement PromotionPercentageDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.PromotionPercentageDecimalDropdownXPath));
            }
        }

        public IWebElement NewSalaryPercentageDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.NewSalaryPercentageDecimalDropdownXPath));
            }
        }

        public IWebElement MeritHourlyDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.MeritHourlyDecimalDropdownXPath));
            }
        }

        public IWebElement LumpSumHourlyDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.LumpSumHourlyDecimalDropdownXPath));
            }
        }

        public IWebElement AdjustmentHourlyDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.AdjustmentHourlyDecimalDropdownXPath));
            }
        }

        public IWebElement CompRatioHourlyDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.CompRatioHourlyDecimalDropdownXPath));
            }
        }

        public IWebElement PromotionHourlyDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.PromotionHourlyDecimalDropdownXPath));
            }
        }

        public IWebElement NewSalaryHourlyDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.NewSalaryHourlyDecimalDropdownXPath));
            }
        }

        public IWebElement MeritAnnualDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.MeritAnnualDecimalDropdownXPath));
            }
        }

        public IWebElement LumpSumAnnualDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.LumpSumAnnualDecimalDropdownXPath));
            }
        }

        public IWebElement AdjustmentAnnualDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.AdjustmentAnnualDecimalDropdownXPath));
            }
        }

        public IWebElement CompRatioAnnualDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.CompRatioAnnualDecimalDropdownXPath));
            }
        }

        public IWebElement PromotionAnnualDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.PromotionAnnualDecimalDropdownXPath));
            }
        }

        public IWebElement NewSalaryAnnualDecimalDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.NewSalaryAnnualDecimalDropdownXPath));
            }
        }

        public IWebElement PasswordLengthDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.PasswordLengthDropdownXPath));
            }
        }

        public IWebElement UserNameFormatDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.UserNameFormatDropdownXPath));
            }
        }

        public IWebElement EmployeeNameFormatDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.EmployeeNameFormatDropdownXPath));
            }
        }

        public IWebElement EmployeeNameSortOrderDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.EmployeeNameSortOrderDropdownXPath));
            }
        }

        public IWebElement DateFormatDropdown
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.DateFormatDropdownXPath));
            }
        }

        public IWebElement CurrencyCode
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.CurrencyCodeCSS));
            }
        }

        public IWebElement CurrencySymbol
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.CurrencyCodeCSS));
            }
        }

        public IWebElement ProrateMethodDailyButton
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.ProrateMethodDailyButtonCSS));
            }
        }

        public IWebElement ProrateMethodWeeklyButton
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.ProrateMethodWeeklyButtonCSS));
            }
        }

        public IWebElement ProrateMethodMonthlyButton
        {
            get
            {
                return browser.FindElement(By.CssSelector(RulesResource.ProrateMethodMonthlyButtonCSS));
            }
        }

        public IWebElement ProrateCalendarDurationTextBox
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.ProrateCalendarDurationTextBoxID));
            }
        }

        public IWebElement ProrateEmployeeWorkedInMonthTextBox
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.ProrateEmployeeWorkedInMonthTextBoxID));
            }
        }

        public IWebElement ProrateRuleForBudgetCheckBox
        {
            get
            {
                return browser.FindElement(By.Id(RulesResource.ProrateRuleForBudgetCheckBoxID));
            }
        }

        public ReadOnlyCollection<IWebElement> ProrateDatePickerSelectIcons
        {
            get
            {
                return browser.FindElements(By.ClassName(RulesResource.ProrateDatePickerSelectIconsClass));
            }
        }

        public IWebElement ProrateStartDateTile
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.ProrateStartDateTileXPath));
            }
        }

        public IWebElement ProrateEndDateTile
        {
            get
            {
                return browser.FindElement(By.XPath(RulesResource.ProrateEndDateTileXPath));
            }
        }
        #endregion

        #region RulesMethodElement
        public IWebElement MeritPercentageRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.MeritPercentageRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement LumpSumPercentageRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.LumpSumPercentageRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement AdjustmentPercentageRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.AdjustmentPercentageRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement CompRatioPercentageRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.CompRatioPercentageRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement PromotionPercentageRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.PromotionPercentageRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement NewSalaryPercentageRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.NewSalaryPercentageRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement MeritHourlyRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.MeritHourlyRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement LumpSumHourlyRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.LumpSumHourlyRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement AdjustmentHourlyRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.AdjustmentHourlyRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement CompRatioHourlyRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.CompRatioHourlyRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement PromotionHourlyRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.PromotionHourlyRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement NewSalaryHourlyRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.NewSalaryHourlyRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement MeritAnnualRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.MeritAnnualRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement LumpSumAnnualRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.LumpSumAnnualRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement AdjustmentAnnualRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.AdjustmentAnnualRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement CompRatioAnnualRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.CompRatioAnnualRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement PromotionAnnualRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.PromotionAnnualRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement NewSalaryAnnualRoundingDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.NewSalaryAnnualRoundingDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement MeritPercentageDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.MeritPercentageDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement LumpSumPercentageDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.LumpSumPercentageDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement AdjustmentPercentageDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.AdjustmentPercentageDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement CompRatioPercentageDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.CompRatioPercentageDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement PromotionPercentageDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.PromotionPercentageDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement NewSalaryPercentageDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.NewSalaryPercentageDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement MeritHourlyDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.MeritHourlyDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement LumpSumHourlyDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.LumpSumHourlyDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement AdjustmentHourlyDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.AdjustmentHourlyDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement CompRatioHourlyDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.CompRatioHourlyDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement PromotionHourlyDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.PromotionHourlyDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement NewSalaryHourlyDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.NewSalaryHourlyDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement MeritAnnualDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.MeritAnnualDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement LumpSumAnnualDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.LumpSumAnnualDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement AdjustmentAnnualDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.AdjustmentAnnualDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement CompRatioAnnualDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.CompRatioAnnualDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement PromotionAnnualDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.PromotionAnnualDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement NewSalaryAnnualDecimalDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.NewSalaryAnnualDecimalDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement PasswordLengthDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.PasswordLengthDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement UserNameFormatDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.UserNameFormatDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement EmployeeNameFormatDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.EmployeeNameFormatDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement EmployeeNameSortOrderDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.EmployeeNameSortOrderDropdownValueXPath + value + RulesResource.XPathClose));
        }

        public IWebElement DateFormatDropdownValue(string value)
        {
            return browser.FindElement(By.XPath(RulesResource.DateFormatDropdownValueXPath + value + RulesResource.XPathClose));
        }    
        
        public IWebElement ChooseProrateStartDateYear(string year)
        {
            return browser.FindElement(By.XPath(RulesResource.ChooseProrateStartDateYearXPath + year+RulesResource.XPathClose));
        }

        public IWebElement ChooseProrateStartDateMonth(string month)
        {
            return browser.FindElement(By.XPath(RulesResource.ChooseProrateStartDateMonthXPath + month + RulesResource.XPathClose));
        }

        public IWebElement ChooseProrateStartDateDay(string day)
        {
            return browser.FindElement(By.XPath(RulesResource.ChooseProrateStartDateDayXPath + day + RulesResource.XPathClose));
        }

        public IWebElement ChooseProrateEndDateYear(string year)
        {
            return browser.FindElement(By.XPath(RulesResource.ChooseProrateEndDateYearXPath + year + RulesResource.XPathClose));
        }

        public IWebElement ChooseProrateEndDateMonth(string month)
        {
            return browser.FindElement(By.XPath(RulesResource.ChooseProrateEndDateMonthXPath + month + RulesResource.XPathClose));
        }

        public IWebElement ChooseProrateEndDateDay(string day)
        {
            return browser.FindElement(By.XPath(RulesResource.ChooseProrateEndDateDayXPath + day + RulesResource.XPathClose));
        }
        #endregion
    }
}
