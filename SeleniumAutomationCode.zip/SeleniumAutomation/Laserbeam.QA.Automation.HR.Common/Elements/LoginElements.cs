﻿using Laserbeam.QA.Automation.HR.Common.Resources;
using OpenQA.Selenium;

namespace Laserbeam.QA.Automation.HR.Common.Elements
{
    public class LoginElements
    {
        #region Fields
        private readonly IWebDriver browser;
        #endregion

        #region Constructor
        public LoginElements(IWebDriver m_browser)
        {
            browser = m_browser;
        }
        #endregion

        #region LoginPropertyElements
        public IWebElement UserNameTextBox
        {
            get
            {
                return browser.FindElement(By.Id(LoginResource.UserNameTextBoxID));
            }
        }

        public IWebElement UserPasswordTextBox
        {
            get
            {
                return browser.FindElement(By.Id(LoginResource.UserPasswordTextBoxID));
            }
        }

        public IWebElement LoginButton
        {
            get
            {
                return browser.FindElement(By.TagName(LoginResource.LoginButtonTagName));
            }
        }

        public IWebElement LoginErrorMessage
        {
            get
            {
                return browser.FindElement(By.ClassName(LoginResource.ErrorMessageClass));
            }
        }

        public string CurrentURL
        {
            get
            {
                return browser.Url;
            }
        }
        #endregion
    }
}
